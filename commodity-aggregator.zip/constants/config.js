export const quantityProducts = 21 // количество товаров на странице категории
export const visibleSliderProducts = 4 // количество видимых товаров в 1 слайде слайдера похожих товаров
export const visibleProductsMainSlider = 5 //количество видимых товаров в 1 слайде слайдера популярных товаров на главной
export const quantityProductsMainSlider = 10 // количество товаров в сладере на главной странице