"use strict";
exports.id = 132;
exports.ids = [132];
exports.modules = {

/***/ 9514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DA": () => (/* binding */ visibleSliderProducts),
/* harmony export */   "Lm": () => (/* binding */ quantityProductsMainSlider),
/* harmony export */   "O1": () => (/* binding */ quantityProducts),
/* harmony export */   "_X": () => (/* binding */ visibleProductsMainSlider)
/* harmony export */ });
const quantityProducts = 21 // количество товаров на странице категории
;
const visibleSliderProducts = 4 // количество видимых товаров в 1 слайде слайдера похожих товаров
;
const visibleProductsMainSlider = 5 //количество видимых товаров в 1 слайде слайдера популярных товаров на главной
;
const quantityProductsMainSlider = 10 // количество товаров в сладере на главной странице
;


/***/ }),

/***/ 5849:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ getCategories)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3695);

const getCategories = async ()=>{
    return await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("products/categories/?per_page=100");
};


/***/ }),

/***/ 8415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ getProductsData)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3695);
/* harmony import */ var _constants_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9514);


const getProductsData = async (categoryId, numPage, qntProducts)=>{
    if (numPage) {
        return await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`products?category=${categoryId}&page=${numPage}&per_page=${qntProducts}`);
    } else {
        return await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`products?category=${categoryId}&page=1&per_page=${_constants_config__WEBPACK_IMPORTED_MODULE_1__/* .quantityProducts */ .O1}`);
    }
};


/***/ })

};
;