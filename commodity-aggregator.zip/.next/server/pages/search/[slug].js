"use strict";
(() => {
var exports = {};
exports.id = 881;
exports.ids = [881];
exports.modules = {

/***/ 2916:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _slug_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/layouts/header.js
var header = __webpack_require__(5904);
// EXTERNAL MODULE: ./components/layouts/footer.js
var footer = __webpack_require__(5689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/filter.js
var filter = __webpack_require__(6498);
// EXTERNAL MODULE: ./components/breadcrumbs.js
var breadcrumbs = __webpack_require__(1865);
// EXTERNAL MODULE: ./components/caption.js
var components_caption = __webpack_require__(2059);
// EXTERNAL MODULE: ./components/searchBlock.js
var searchBlock = __webpack_require__(913);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/layouts/MainLayout.js










const CatalogLayout = ({ children , caption  })=>{
    const pathLocation = (0,router_.useRouter)().pathname;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "content",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "site__container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(searchBlock/* default */.Z, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "site__main__wrap folder",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("main", {
                            role: "main",
                            className: "site__main folder",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "site__main__in",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(breadcrumbs/* default */.Z, {
                                        path: pathLocation,
                                        namePage: caption
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(components_caption/* default */.Z, {
                                        caption: caption
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mode_folder_wrapper",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "mode_folder_body",
                                            children: children
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
};
/* harmony default export */ const MainLayout = (CatalogLayout);

// EXTERNAL MODULE: ./api/index.js
var api = __webpack_require__(3695);
;// CONCATENATED MODULE: ./utils/searchProducts.js


const getSearchProducts = async (query)=>{
    return await api/* default.get */.Z.get(`products?search=${query}&per_page=100`);
};

// EXTERNAL MODULE: ./components/productList.js
var productList = __webpack_require__(3062);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/search/[slug].js







const SearchProducts = ({ searchResults  })=>{
    console.log("SearchResults Length >> ", searchResults.length);
    const searchQuery = (0,router_.useRouter)().query.id;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "\u041F\u043E\u0438\u0441\u043A \u0442\u043E\u0432\u0430\u0440\u043E\u0432"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "\u0417\u0434\u0435\u0441\u044C \u0412\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u043D\u0430\u0439\u0442\u0435 \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u0443\u044E\u0449\u0438\u0439 \u0442\u043E\u0432\u0430\u0440 \u0432 \u043D\u0430\u0448\u0435\u043C \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0435 \u043F\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "robots",
                        content: "noindex, follow"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MainLayout, {
                caption: "\u041F\u043E\u0438\u0441\u043A \u0442\u043E\u0432\u0430\u0440\u043E\u0432",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "search__message",
                        children: [
                            "\u041F\u043E \u0437\u0430\u043F\u0440\u043E\u0441\u0443 ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: searchQuery
                            }),
                            " \u043D\u0430\u0439\u0434\u0435\u043D\u043E ",
                            searchResults.length,
                            " \u0442\u043E\u0432\u0430\u0440\u043E\u0432."
                        ]
                    }),
                    searchResults.length ? /*#__PURE__*/ jsx_runtime_.jsx(productList/* default */.Z, {
                        products: searchResults
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "g-notice g-notice--indents",
                        children: [
                            "\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E. \u0412\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0432\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u043D\u0430  ",
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: "\u0433\u043B\u0430\u0432\u043D\u0443\u044E"
                                })
                            }),
                            " \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u0441\u0430\u0439\u0442\u0430 \u0438\u043B\u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u0432\u043E\u0439 \u0437\u0430\u043F\u0440\u043E\u0441 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u043F\u043E\u0438\u0441\u043A."
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const _slug_ = (SearchProducts);
async function getServerSideProps(ctx) {
    console.log(ctx);
    const { data: searchResults  } = await getSearchProducts(encodeURI(ctx.query.id));
    return {
        props: {
            searchResults: searchResults
        }
    };
}


/***/ }),

/***/ 1824:
/***/ ((module) => {

module.exports = require("@woocommerce/woocommerce-rest-api");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,675,406,38,498,872,913,62], () => (__webpack_exec__(2916)));
module.exports = __webpack_exports__;

})();