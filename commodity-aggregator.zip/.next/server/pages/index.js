"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 3695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const WooCommerceRestApi = (__webpack_require__(1824)["default"]);
const api = new WooCommerceRestApi({
    url: "https://cms.moscow-shiny.ru",
    consumerKey: process.env.WC_CONSUMER_KEY,
    consumerSecret: process.env.WC_CONSUMER_SECRET,
    version: "wc/v3"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (api);


/***/ }),

/***/ 4720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/layouts/header.js
var header = __webpack_require__(5904);
// EXTERNAL MODULE: ./components/searchBlock.js
var searchBlock = __webpack_require__(913);
// EXTERNAL MODULE: ./utils/products.js
var products = __webpack_require__(8415);
// EXTERNAL MODULE: ./components/layouts/footer.js
var footer = __webpack_require__(5689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./constants/config.js
var config = __webpack_require__(9514);
;// CONCATENATED MODULE: ./components/popularProductsSlider.js





const PopularProductsSlider = ({ data , caption  })=>{
    const visibleProduct = config/* visibleProductsMainSlider */._X;
    const { 0: indexEl , 1: setSliderPopularIndex  } = (0,external_react_.useState)(0);
    const handleArrow = (direction)=>{
        if (direction === "left") {
            setSliderPopularIndex(indexEl !== 0 ? indexEl - 1 : data.length - visibleProduct);
        }
        if (direction === "right") {
            setSliderPopularIndex(indexEl !== data.length - visibleProduct ? indexEl + 1 : 0);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "popular__block__wrapper",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "popular__block__wrap",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "block__title",
                        children: caption
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "block__slider",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "prod_list_wrap",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "button",
                                    className: "slick-prev slick-arrow",
                                    onClick: ()=>handleArrow("left")
                                    ,
                                    children: "Previous"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "slick-list draggable",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "slick-track",
                                        style: {
                                            transform: `translateX(${-245 * indexEl}px)`
                                        },
                                        children: data.map((product)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "main__block__item slick-slide",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                    className: "shop2-product-item",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "product__image",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: {
                                                                    pathname: `/p/${product.slug}`,
                                                                    query: {
                                                                        id: product.id
                                                                    }
                                                                },
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                        src: product.images.length ? product.images[0].src : "/images/no_image.png",
                                                                        alt: product.name,
                                                                        width: 200,
                                                                        height: 200
                                                                    })
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "product__name",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: {
                                                                    pathname: `/p/${product.slug}`,
                                                                    query: {
                                                                        id: product.id
                                                                    }
                                                                },
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    children: product.name
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "product__price",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "price-old question",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: product.regular_price
                                                                            }),
                                                                            " \u0440\u0443\u0431."
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "price-current",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                            children: product.sale_price
                                                                        }),
                                                                        " \u0440\u0443\u0431."
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }, product.id)
                                        )
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "button",
                                    className: "slick-next slick-arrow",
                                    onClick: ()=>handleArrow("right")
                                    ,
                                    children: "Next"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "slick-dots",
                                    children: data.map((product, index)=>{
                                        if (index < data.length - visibleProduct + 1) {
                                            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: indexEl == index ? "slick-active" : "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "button",
                                                    children: index
                                                })
                                            }, product.id);
                                        }
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const popularProductsSlider = (PopularProductsSlider);

// EXTERNAL MODULE: ./utils/categories.js
var utils_categories = __webpack_require__(5849);
;// CONCATENATED MODULE: ./pages/index.js










function Home({ productsTires , productsDiscs , categories  }) {
    (0,external_react_.useEffect)(()=>{
        // const categoriesBlock = Array.from(document.getElementsByClassName('popular__folders__block'))
        // const categoriesBlockHeight = categoriesBlock[0].scrollHeight
        // setCategoriesBlockHeight(categoriesBlockHeight)
        //слайдер
        const slickTrack = Array.from(document.getElementsByClassName("slick-track"));
        slickTrack.forEach((elem, index)=>{
            slickTrack[index].style.width = productsTires.length * 245 + "px";
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "\u041A\u0443\u043F\u0438\u0442\u044C \u0448\u0438\u043D\u044B \u0432 \u041C\u043E\u0441\u043A\u0432\u0435 \u2014 \u043D\u0435\u0434\u043E\u0440\u043E\u0433\u043E, \u0437\u0438\u043C\u043D\u0438\u0435 \u0438 \u043B\u0435\u0442\u043D\u0438\u0435 \u0441\u043E \u0441\u043A\u043B\u0430\u0434\u0430"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "\u041D\u0430\u0448 \u0441\u0435\u0440\u0432\u0438\u0441 \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043A\u0443\u043F\u0438\u0442\u044C \u043D\u0435\u0434\u043E\u0440\u043E\u0433\u043E \u0448\u0438\u043D\u044B \u0432 \u041C\u043E\u0441\u043A\u0432\u0435 \u0432 \u043F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0445 \u0418\u043D\u0442\u0435\u0440\u043D\u0435\u0442-\u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0430\u0445. \u0420\u0430\u0441\u043F\u0440\u043E\u0434\u0430\u0436\u0430 \u0437\u0438\u043C\u043D\u0438\u0445 \u0438 \u043B\u0435\u0442\u043D\u0438\u0445 \u0430\u0432\u0442\u043E\u0448\u0438\u043D \u0441\u043E \u0441\u043A\u043B\u0430\u0434\u0430 \u0432 \u0433. \u041C\u043E\u0441\u043A\u0432\u0430 \u043D\u0430 \u0432\u044B\u0433\u043E\u0434\u043D\u044B\u0445 \u0443\u0441\u043B\u043E\u0432\u0438\u044F\u0445: \u0441\u043A\u0438\u0434\u043A\u0438 \u043E\u0442 10%, \u0440\u0430\u0441\u0441\u0440\u043E\u0447\u043A\u0430 0%, \u043A\u0440\u0435\u0434\u0438\u0442."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "site__container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(searchBlock/* default */.Z, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(popularProductsSlider, {
                        data: productsTires,
                        caption: "\u041F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0435 \u0448\u0438\u043D\u044B"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(popularProductsSlider, {
                        data: productsDiscs,
                        caption: "\u041F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0435 \u0434\u0438\u0441\u043A\u0438"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text__block__wrapper",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text__block__wrap",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "block__title",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        children: "\u0410\u0432\u0442\u043E\u043C\u043E\u0431\u0438\u043B\u044C\u043D\u044B\u0435 \u0448\u0438\u043D\u044B"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "block__body",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u041F\u043E\u0433\u043E\u0434\u043D\u044B\u0435 \u0443\u0441\u043B\u043E\u0432\u0438\u044F, \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u043C\u044B \u0436\u0438\u0432\u0435\u043C, \u043D\u0435 \u0441\u0430\u043C\u044B\u0435 \u0431\u043B\u0430\u0433\u043E\u043F\u0440\u0438\u044F\u0442\u043D\u044B\u0435 \u0434\u043B\u044F \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0439 \u0435\u0437\u0434\u044B: \u044D\u0442\u043E \u0438 \u0441\u043E\u0440\u043E\u043A\u043E\u0433\u0440\u0430\u0434\u0443\u0441\u043D\u0430\u044F \u0436\u0430\u0440\u0430, \u0438 \u0441\u043E\u0440\u043E\u043A\u0430\u0433\u0440\u0430\u0434\u0443\u0441\u043D\u044B\u0439 \u043C\u043E\u0440\u043E\u0437. \u041F\u043E\u044D\u0442\u043E\u043C\u0443 \u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0438\u043B\u044C\u043D\u044B\u0435 \u0448\u0438\u043D\u044B \u043D\u0443\u0436\u0434\u0430\u044E\u0442\u0441\u044F \u0432 \u0440\u0435\u0433\u0443\u043B\u044F\u0440\u043D\u043E\u0439 \u0437\u0430\u043C\u0435\u043D\u0435."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u0427\u0442\u043E\u0431\u044B \u043D\u0435 \u0442\u0440\u0430\u0442\u0438\u0442 \u0441\u0432\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u043D\u0430 \u043F\u043E\u0438\u0441\u043A \u0445\u043E\u0440\u043E\u0448\u0435\u0433\u043E \u0438 \u043D\u0435\u0434\u043E\u0440\u043E\u0433\u043E \u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0430, \u0437\u0430\u043D\u0438\u043C\u0430\u044E\u0449\u0435\u0433\u043E\u0441\u044F \u043F\u0440\u043E\u0434\u0430\u0436\u0435\u0439 \u0442\u0430\u043A\u0438\u0445 \u0442\u043E\u0432\u0430\u0440\u043E\u0432, \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u043C \u0432\u0430\u0448\u0435\u043C\u0443 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044E \u043D\u0430\u0448 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442-\u043C\u0430\u0433\u0430\u0437\u0438\u043D. \u041D\u0430 \u043D\u0430\u0448\u0435\u043C \u0441\u0430\u0439\u0442\u0435 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D \u0448\u0438\u0440\u043E\u043A\u0438\u0439 \u0430\u0441\u0441\u043E\u0440\u0442\u0438\u043C\u0435\u043D\u0442, \u043D\u0430\u0434\u0435\u0436\u043D\u044B\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u0438 \u0438 \u0442\u043E\u0432\u0430\u0440 \u0432\u044B\u0441\u043E\u043A\u043E\u0433\u043E \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0430."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u041D\u0430\u0448 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442-\u043C\u0430\u0433\u0430\u0437\u0438\u043D \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u0441\u0434\u0435\u043B\u0430\u0442\u044C \u0441\u0432\u043E\u0439 \u0432\u044B\u0431\u043E\u0440 \u043E\u0431\u0434\u0443\u043C\u0430\u043D\u043D\u043E \u0438 \u043D\u0435 \u0441\u043F\u0435\u0448\u0430, \u0442\u0449\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u0438\u0437\u0443\u0447\u0438\u0432 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438 \u043F\u043E\u043D\u0440\u0430\u0432\u0438\u0432\u0448\u0435\u0433\u043E\u0441\u044F \u0442\u043E\u0432\u0430\u0440\u0430. \u0420\u0430\u0437\u043B\u0438\u0447\u043D\u0430\u044F \u0446\u0435\u043D\u043E\u0432\u0430\u044F \u043F\u043E\u043B\u0438\u0442\u0438\u043A\u0430, \u043E\u0442 \u0441\u0430\u043C\u044B\u0445 \u0431\u044E\u0434\u0436\u0435\u0442\u043D\u044B\u0445 \u0434\u043E \u043F\u0440\u0435\u043C\u0438\u0443\u043C \u043A\u043B\u0430\u0441\u0441\u0430, \u0440\u0430\u0437\u043B\u0438\u0447\u043D\u044B\u0435 \u0434\u0438\u0430\u043C\u0435\u0442\u0440\u044B, \u0448\u0438\u0440\u0438\u043D\u0430 \u043F\u0440\u043E\u0444\u0438\u043B\u044F, \u0441\u0435\u0437\u043E\u043D\u043D\u043E\u0441\u0442\u044C (\u0437\u0438\u043C\u043D\u0438\u0435, \u043B\u0435\u0442\u043D\u0438\u0435, \u0432\u0441\u0435\u0441\u0435\u0437\u043E\u043D\u043D\u044B\u0435), \u043F\u0440\u043E\u0441\u0442\u044B\u0435 \u0438 \u0448\u0438\u043F\u043E\u0432\u0430\u043D\u043D\u044B\u0435."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u0423 \u043D\u0430\u0441 \u0441\u0430\u043C\u044B\u0435 \u0440\u0430\u0437\u0443\u043C\u043D\u044B\u0435 \u0438 \u043E\u0431\u043E\u0441\u043D\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0446\u0435\u043D\u044B \u0432 \u041C\u043E\u0441\u043A\u0432\u0435. \u041D\u0435 \u043D\u0443\u0436\u043D\u043E \u0442\u0440\u0430\u0442\u0438\u0442\u044C \u0432\u0440\u0435\u043C\u044F \u0438 \u0431\u0435\u043D\u0437\u0438\u043D \u043D\u0430 \u0442\u043E, \u0447\u0442\u043E\u0431\u044B \u043E\u0431\u044A\u0435\u0437\u0434\u0438\u0442\u044C \u0432\u0441\u0435 \u0442\u043E\u0447\u043A\u0438 \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u0438 \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u0442\u043E, \u0447\u0442\u043E \u043F\u043E\u043D\u0440\u0430\u0432\u0438\u0442\u0441\u044F. \u041F\u043E\u043A\u0443\u043F\u043A\u0430 \u043D\u043E\u0432\u043E\u0439 \u0440\u0435\u0437\u0438\u043D\u044B \u2013 \u044D\u0442\u043E \u0432\u0441\u0435\u0433\u0434\u0430 \u0437\u0430\u0442\u0440\u0430\u0442\u043D\u043E. \u0425\u043E\u0440\u043E\u0448\u0430\u044F \u0438 \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043F\u0440\u043E\u0434\u0443\u043A\u0446\u0438\u044F \u0432\u0441\u0435\u0433\u0434\u0430 \u0441\u0442\u043E\u0438\u0442 \u0434\u043E\u0440\u043E\u0433\u043E. \u041D\u043E \u0443 \u043D\u0430\u0441 \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u043F\u0440\u0438\u043E\u0431\u0440\u0435\u0441\u0442\u0438 \u043D\u0435\u0434\u043E\u0440\u043E\u0433\u043E \u043B\u044E\u0431\u0443\u044E \u043C\u043E\u0434\u0435\u043B\u044C, \u043A\u043E\u0442\u043E\u0440\u0430\u044F \u0431\u0443\u0434\u0435\u0442 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0432\u0441\u0435\u043C \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0430\u043C \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0430"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
}
/* harmony default export */ const pages = (Home);
async function getServerSideProps() {
    const { data: productsTires  } = await (0,products/* getProductsData */.d)(16, 1, config/* quantityProductsMainSlider */.Lm);
    const { data: productsDiscs  } = await (0,products/* getProductsData */.d)(17, 1, config/* quantityProductsMainSlider */.Lm);
    const { data: categories  } = await (0,utils_categories/* getCategories */.C)();
    return {
        props: {
            productsTires: productsTires ?? {},
            productsDiscs: productsDiscs ?? {},
            categories: categories ?? {}
        }
    };
}


/***/ }),

/***/ 1824:
/***/ ((module) => {

module.exports = require("@woocommerce/woocommerce-rest-api");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,675,406,913,132], () => (__webpack_exec__(4720)));
module.exports = __webpack_exports__;

})();