"use strict";
(() => {
var exports = {};
exports.id = 871;
exports.ids = [871];
exports.modules = {

/***/ 9514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DA": () => (/* binding */ visibleSliderProducts),
/* harmony export */   "Lm": () => (/* binding */ quantityProductsMainSlider),
/* harmony export */   "O1": () => (/* binding */ quantityProducts),
/* harmony export */   "_X": () => (/* binding */ visibleProductsMainSlider)
/* harmony export */ });
const quantityProducts = 21 // количество товаров на странице категории
;
const visibleSliderProducts = 4 // количество видимых товаров в 1 слайде слайдера похожих товаров
;
const visibleProductsMainSlider = 5 //количество видимых товаров в 1 слайде слайдера популярных товаров на главной
;
const quantityProductsMainSlider = 10 // количество товаров в сладере на главной странице
;


/***/ }),

/***/ 5680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProductPage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/layouts/header.js
var header = __webpack_require__(5904);
// EXTERNAL MODULE: ./components/breadcrumbs.js
var breadcrumbs = __webpack_require__(1865);
// EXTERNAL MODULE: ./components/caption.js
var caption = __webpack_require__(2059);
// EXTERNAL MODULE: ./components/layouts/footer.js
var footer = __webpack_require__(5689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./api/index.js
var api = __webpack_require__(3695);
;// CONCATENATED MODULE: ./utils/product.js

const getProductData = async (productId)=>{
    return await api/* default.get */.Z.get(`products/${productId}`);
};

// EXTERNAL MODULE: ./components/goToPartner.js
var goToPartner = __webpack_require__(9447);
// EXTERNAL MODULE: ./components/productCard.js
var productCard = __webpack_require__(5462);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./constants/config.js
var config = __webpack_require__(9514);
;// CONCATENATED MODULE: ./components/productsSliderProductCard.js




const ProductsSliderProductCard = ({ relatedProducts  })=>{
    const { 0: indexEl , 1: setSliderProductIndex  } = (0,external_react_.useState)(0);
    const visibleProducts = config/* visibleSliderProducts */.DA;
    const { 0: blockWidth , 1: setBlockWidth  } = (0,external_react_.useState)(0);
    const { 0: marginItem , 1: setMarginItem  } = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        let productBlockWidth = Array.from(document.getElementsByClassName("shop2_product_item"));
        setBlockWidth(productBlockWidth[0].scrollWidth);
    }, []);
    function handleArrow(direction) {
        if (direction === "left") {
            setSliderProductIndex(indexEl !== 0 ? indexEl - 1 : relatedProducts.length - visibleProducts);
            setMarginItem(30);
        }
        if (direction === "right") {
            setSliderProductIndex(indexEl !== relatedProducts.length - visibleProducts ? indexEl + 1 : 0);
            setMarginItem(30);
        }
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "shop_group_kinds slick-initialized slick-slider",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                className: "slick-prev slick-arrow slick-disabled",
                onClick: ()=>handleArrow("left")
                ,
                children: "Previous"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "slick-list",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    id: "relatedProductsSlider",
                    className: "slick-track",
                    style: {
                        transform: `translateX(-${(blockWidth + marginItem) * indexEl}px)`,
                        width: `${relatedProducts.length * blockWidth + 30 * relatedProducts.length}px`
                    },
                    children: relatedProducts.map((item)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(productCard/* default */.Z, {
                            productData: item
                        }, item.id);
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                className: "slick-next slick-arrow",
                onClick: ()=>handleArrow("right")
                ,
                children: "Next"
            })
        ]
    });
};
/* harmony default export */ const productsSliderProductCard = (ProductsSliderProductCard);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/tabContent.js

const TabContent = ({ title , content , tabIndex  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "shop_product_desc",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `desc-area desc-area${tabIndex}`,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "shop_product_params",
                    children: [
                        tabIndex === 0 && content.map((item)=>{
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "param_item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "param_title",
                                        children: item.name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "param_body",
                                        children: item.options[0]
                                    })
                                ]
                            }, item.position);
                        }),
                        tabIndex === 1 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: content
                            }
                        }) : false
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "shop2-clear-container"
                })
            ]
        })
    });
};
/* harmony default export */ const tabContent = (TabContent);

;// CONCATENATED MODULE: ./components/tabs.js



const Tabs = ({ items  })=>{
    const { 0: active , 1: setActive  } = (0,external_react_.useState)(0);
    const openTab = (e)=>{
        setActive(+e.target.dataset.index);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "shop_product_tabs r-tabs-nav",
                children: items.map((item, index)=>{
                    return item.content && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: `${index === active ? "active-tab" : ""}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            onClick: openTab,
                            "data-index": index,
                            children: item.title
                        })
                    }, index);
                })
            }),
            items[active] && /*#__PURE__*/ jsx_runtime_.jsx(tabContent, {
                className: "her",
                ...items[active],
                tabIndex: active
            })
        ]
    });
};
/* harmony default export */ const tabs = (Tabs);

;// CONCATENATED MODULE: ./pages/p/[slug].js














function ProductPage({ product , upsellProducts  }) {
    console.log("product > ", product);
    const pathLocation = (0,router_.useRouter)().pathname;
    const customFields = product.meta_data;
    const vendor = product.meta_data.find((item)=>item.key == "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C"
    );
    const title = product.meta_data.find((item)=>item.key == "wc_title"
    );
    const description = product.meta_data.find((item)=>item.key == "wc_desctiption"
    );
    const shopName = customFields.find((item)=>item.key == "shop_name"
    ).value;
    const tabsItems = [
        {
            title: "\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438",
            content: product.attributes
        },
        {
            title: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435",
            content: product.description
        }
    ];
    function mathDiscount(salePrice, regularPrice) {
        let percent = (regularPrice - salePrice) * 100 / regularPrice;
        return percent.toFixed(0);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title ? title.value : `${product.name} купить в Интернет-магазине с доставкой недорого`
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: description ? description.value : `${product.name} купить в Интернет-магазине с доставкой по России всего за ${product.price} руб. Производитель ${vendor.value}. Артикул ${product.sku} `
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "site__container product",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "site__main__wrap product",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("main", {
                        role: "main",
                        className: "site__main product",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "site__main__in",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(breadcrumbs/* default */.Z, {
                                    isProduct: true,
                                    path: pathLocation,
                                    namePage: product.name,
                                    parentCategoryName: product.categories[0].name,
                                    parentCategoryUrl: `${product.categories[0].slug}` + "?id=" + `${product.categories[0].id}`
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "product_top_wrapper",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                        method: "post",
                                        className: "shop2-product",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "product_side_l",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "product_slider_wr",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "product_labels",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "product_label_item product_sale",
                                                                children: [
                                                                    "-",
                                                                    mathDiscount(product.sale_price, product.regular_price),
                                                                    " %"
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "product_slider",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "product_image",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                    src: product.images.length ? product.images[0].src : "/images/no_image.png",
                                                                    alt: product.name,
                                                                    title: "",
                                                                    width: "460",
                                                                    height: "460"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "product_side_r",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "product_top_block",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "product-compare",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                            type: "checkbox"
                                                                        }),
                                                                        "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043A \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E"
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "product_name",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(caption/* default */.Z, {
                                                                    caption: product.name
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "vendor_option"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "product_bot_block",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "shop2_product_options_wr",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "shop2_product_options",
                                                                    children: product.attributes.map((item, index)=>{
                                                                        if (index < 4) {
                                                                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: "option_item odd type-select",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                        className: "option_title",
                                                                                        children: [
                                                                                            item.name,
                                                                                            ":"
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        className: "option_body",
                                                                                        children: item.options[0]
                                                                                    })
                                                                                ]
                                                                            }, item.position);
                                                                        }
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "product-price",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "price-old question",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                    children: product.regular_price
                                                                                }),
                                                                                " \u0440\u0443\u0431."
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "price-current",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: product.price
                                                                            }),
                                                                            " \u0440\u0443\u0431."
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "product_buttons",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "product_buttons_in",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(goToPartner/* default */.Z, {
                                                                        url: product.external_url,
                                                                        shopName: shopName
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "product_categories_block",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "caption",
                                                                children: "\u0422\u043E\u0432\u0430\u0440 \u043D\u0430\u0445\u043E\u0434\u0438\u0442\u0441\u044F \u0432 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F\u0445:"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "links",
                                                                children: product.categories.map((item)=>{
                                                                    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: {
                                                                            pathname: `/catalog/${item.slug}`,
                                                                            query: {
                                                                                id: item.id
                                                                            }
                                                                        },
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                            children: item.name
                                                                        })
                                                                    }, item.id);
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "shop_product_data",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "shop_product_tabs_wr",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(tabs, {
                                                items: tabsItems
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "shop2-clear-container"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "shop_kind_wrap",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "shop_collection_header",
                                            children: "\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C\u044B\u0435 \u0442\u043E\u0432\u0430\u0440\u044B"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(productsSliderProductCard, {
                                            relatedProducts: upsellProducts
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
};
async function getServerSideProps(context) {
    const { data: product  } = await getProductData(context.query.id);
    const upsellProductsIds = [];
    const crossSellProductsIds = [];
    product.upsell_ids.map((item, index)=>{
        if (index < 6) {
            upsellProductsIds.push(item);
        }
    });
    product.cross_sell_ids.map((item, index)=>{
        if (index < 6) {
            crossSellProductsIds.push(item);
        }
    });
    const upsellIds = [];
    const crossSellIds = [];
    // for (const item of upsellProductsIds){
    //     let {data:upsellProduct} = await getProductData(item)
    //     upsellIds.push(upsellProduct)
    // }
    // for (const item of crossSellProductsIds){
    //     let {data:crossSellProduct} = await getProductData(item)
    //     crossSellIds.push(crossSellProduct)
    // }
    await Promise.all(upsellProductsIds.map(async (item)=>{
        let { data: upsellProduct  } = await getProductData(item);
        upsellIds.push(upsellProduct);
    }));
    // await Promise.all(crossSellProductsIds.map(async (item) => {
    //     let {data:crossSellProduct} = await getProductData(item)
    //     crossSellIds.push(crossSellProduct)
    // }))
    return {
        props: {
            product: product ?? {},
            upsellProducts: upsellIds ?? {},
            crossSellProducts: crossSellIds ?? {}
        }
    };
}


/***/ }),

/***/ 1824:
/***/ ((module) => {

module.exports = require("@woocommerce/woocommerce-rest-api");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,675,406,38,872], () => (__webpack_exec__(5680)));
module.exports = __webpack_exports__;

})();