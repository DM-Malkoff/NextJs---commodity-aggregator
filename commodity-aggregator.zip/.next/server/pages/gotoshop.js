"use strict";
(() => {
var exports = {};
exports.id = 852;
exports.ids = [852];
exports.modules = {

/***/ 1990:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ gotoshop),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/dist/shared/lib/styled-jsx"
const styled_jsx_namespaceObject = require("next/dist/shared/lib/styled-jsx");
var styled_jsx_default = /*#__PURE__*/__webpack_require__.n(styled_jsx_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./pages/gotoshop/index.js



const GoToShop = ({ prevUrl  })=>{
    console.log(prevUrl);
    const shopName = localStorage.getItem("shopName");
    (0,external_react_.useEffect)(()=>{
        setTimeout(()=>{
            window.location.assign(localStorage.getItem("external-link"));
            window.history.replaceState(null, null, prevUrl);
        }, 1000);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "jsx-3f2f10e35bdc7846" + " " + "transition-text",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "jsx-3f2f10e35bdc7846" + " " + "loader",
                /*#__PURE__*/ children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "jsx-3f2f10e35bdc7846" + " " + "container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "jsx-3f2f10e35bdc7846" + " " + "box1"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "jsx-3f2f10e35bdc7846" + " " + "box2"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "jsx-3f2f10e35bdc7846" + " " + "box3"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "jsx-3f2f10e35bdc7846",
                children: [
                    "\u041F\u0435\u0440\u0435\u0445\u043E\u0434 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0430 ",
                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                        className: "jsx-3f2f10e35bdc7846",
                        children: shopName
                    })
                ]
            }),
            jsx_runtime_.jsx((styled_jsx_default()), {
                id: "3f2f10e35bdc7846",
                children: ".transition-text.jsx-3f2f10e35bdc7846{position:absolute;top:50%;left:50%;-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.transition-text.jsx-3f2f10e35bdc7846 p.jsx-3f2f10e35bdc7846{}.loader.jsx-3f2f10e35bdc7846{padding:0px;margin:0px;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center}.loader.jsx-3f2f10e35bdc7846 .container.jsx-3f2f10e35bdc7846{width:112px;height:112px}.loader.jsx-3f2f10e35bdc7846 .container.jsx-3f2f10e35bdc7846 .box1.jsx-3f2f10e35bdc7846,.container.jsx-3f2f10e35bdc7846 .box2.jsx-3f2f10e35bdc7846,.container.jsx-3f2f10e35bdc7846 .box3.jsx-3f2f10e35bdc7846{border:16px solid#f5f5f5;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;display:block}.loader.jsx-3f2f10e35bdc7846 .container.jsx-3f2f10e35bdc7846 .box1.jsx-3f2f10e35bdc7846{width:112px;height:48px;margin-top:64px;margin-left:0px;-webkit-animation:anime1 4s 0s forwards ease-in-out infinite;-moz-animation:anime1 4s 0s forwards ease-in-out infinite;-o-animation:anime1 4s 0s forwards ease-in-out infinite;animation:anime1 4s 0s forwards ease-in-out infinite}.loader.jsx-3f2f10e35bdc7846 .container.jsx-3f2f10e35bdc7846 .box2.jsx-3f2f10e35bdc7846{width:48px;height:48px;margin-top:0px;margin-left:0px;-webkit-animation:anime2 4s 0s forwards ease-in-out infinite;-moz-animation:anime2 4s 0s forwards ease-in-out infinite;-o-animation:anime2 4s 0s forwards ease-in-out infinite;animation:anime2 4s 0s forwards ease-in-out infinite}.loader.jsx-3f2f10e35bdc7846 .container.jsx-3f2f10e35bdc7846 .box3.jsx-3f2f10e35bdc7846{width:48px;height:48px;margin-top:0px;margin-left:64px;-webkit-animation:anime3 4s 0s forwards ease-in-out infinite;-moz-animation:anime3 4s 0s forwards ease-in-out infinite;-o-animation:anime3 4s 0s forwards ease-in-out infinite;animation:anime3 4s 0s forwards ease-in-out infinite}@-webkit-keyframes anime1{0%{width:112px;height:48px;margin-top:64px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}25%{width:48px;height:48px;margin-top:64px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}50%{width:48px;height:48px;margin-top:64px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}75%{width:48px;height:112px;margin-top:0px;margin-left:0px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}100%{width:48px;height:48px;margin-top:0px;margin-left:0px}}@-moz-keyframes anime1{0%{width:112px;height:48px;margin-top:64px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}25%{width:48px;height:48px;margin-top:64px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}50%{width:48px;height:48px;margin-top:64px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}75%{width:48px;height:112px;margin-top:0px;margin-left:0px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}100%{width:48px;height:48px;margin-top:0px;margin-left:0px}}@-o-keyframes anime1{0%{width:112px;height:48px;margin-top:64px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}25%{width:48px;height:48px;margin-top:64px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}50%{width:48px;height:48px;margin-top:64px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}75%{width:48px;height:112px;margin-top:0px;margin-left:0px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}100%{width:48px;height:48px;margin-top:0px;margin-left:0px}}@keyframes anime1{0%{width:112px;height:48px;margin-top:64px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}25%{width:48px;height:48px;margin-top:64px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}50%{width:48px;height:48px;margin-top:64px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:0px}75%{width:48px;height:112px;margin-top:0px;margin-left:0px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}100%{width:48px;height:48px;margin-top:0px;margin-left:0px}}@-webkit-keyframes anime2{0%{width:48px;height:48px;margin-top:0px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}25%{width:48px;height:48px;margin-top:0px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}50%{width:112px;height:48px;margin-top:0px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}75%{width:48px;height:48px;margin-top:0px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}100%{width:48px;height:48px;margin-top:0px;margin-left:64px}}@-moz-keyframes anime2{0%{width:48px;height:48px;margin-top:0px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}25%{width:48px;height:48px;margin-top:0px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}50%{width:112px;height:48px;margin-top:0px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}75%{width:48px;height:48px;margin-top:0px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}100%{width:48px;height:48px;margin-top:0px;margin-left:64px}}@-o-keyframes anime2{0%{width:48px;height:48px;margin-top:0px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}25%{width:48px;height:48px;margin-top:0px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}50%{width:112px;height:48px;margin-top:0px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}75%{width:48px;height:48px;margin-top:0px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}100%{width:48px;height:48px;margin-top:0px;margin-left:64px}}@keyframes anime2{0%{width:48px;height:48px;margin-top:0px;margin-left:0px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}25%{width:48px;height:48px;margin-top:0px;margin-left:0px}37.5%{width:48px;height:48px;margin-top:0px;margin-left:0px}50%{width:112px;height:48px;margin-top:0px;margin-left:0px}62.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}75%{width:48px;height:48px;margin-top:0px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}100%{width:48px;height:48px;margin-top:0px;margin-left:64px}}@-webkit-keyframes anime3{0%{width:48px;height:48px;margin-top:0px;margin-left:64px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}25%{width:48px;height:112px;margin-top:0px;margin-left:64px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}50%{width:48px;height:48px;margin-top:64px;margin-left:64px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}75%{width:48px;height:48px;margin-top:64px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}100%{width:112px;height:48px;margin-top:64px;margin-left:0px}}@-moz-keyframes anime3{0%{width:48px;height:48px;margin-top:0px;margin-left:64px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}25%{width:48px;height:112px;margin-top:0px;margin-left:64px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}50%{width:48px;height:48px;margin-top:64px;margin-left:64px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}75%{width:48px;height:48px;margin-top:64px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}100%{width:112px;height:48px;margin-top:64px;margin-left:0px}}@-o-keyframes anime3{0%{width:48px;height:48px;margin-top:0px;margin-left:64px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}25%{width:48px;height:112px;margin-top:0px;margin-left:64px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}50%{width:48px;height:48px;margin-top:64px;margin-left:64px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}75%{width:48px;height:48px;margin-top:64px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}100%{width:112px;height:48px;margin-top:64px;margin-left:0px}}@keyframes anime3{0%{width:48px;height:48px;margin-top:0px;margin-left:64px}12.5%{width:48px;height:48px;margin-top:0px;margin-left:64px}25%{width:48px;height:112px;margin-top:0px;margin-left:64px}37.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}50%{width:48px;height:48px;margin-top:64px;margin-left:64px}62.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}75%{width:48px;height:48px;margin-top:64px;margin-left:64px}87.5%{width:48px;height:48px;margin-top:64px;margin-left:64px}100%{width:112px;height:48px;margin-top:64px;margin-left:0px}}"
            })
        ]
    });
};
/* harmony default export */ const gotoshop = (GoToShop);
async function getServerSideProps(context) {
    return {
        props: {
            prevUrl: context.req.headers.referer
        }
    };
}


/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1990));
module.exports = __webpack_exports__;

})();