export default function Caption({caption}){
    return(
        <h1>{caption || 'Заголовок'}</h1>
    )
}
